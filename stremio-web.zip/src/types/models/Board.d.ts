type Board = CatalogsWithExtra;
